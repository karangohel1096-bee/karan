<?php
session_start();
require_once __DIR__ . '/includes/header.php';
$name = $_SESSION['contact_name'] ?? 'there';
unset($_SESSION['contact_name']);
?>

<main>
  <section class="thankyou-section">
    <div class="check-circle reveal">
      <svg viewBox="0 0 52 52"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M14 27l7 7 17-17"/></svg>
    </div>
    <h1 class="reveal" data-delay="1">Thank you, <span class="gold"><?php echo htmlspecialchars($name); ?></span>!</h1>
    <p class="reveal" data-delay="2">Your message has been sent successfully. I'll get back to you soon.</p>
    <a href="index.php" class="btn btn-gold reveal" data-delay="3">Back to Home</a>
  </section>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
