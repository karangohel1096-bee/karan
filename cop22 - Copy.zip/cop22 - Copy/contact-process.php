<?php
// ============================================
// CONTACT FORM PROCESSOR
// Form data ne validate kare che, pachi PAGE REDIRECT kare che
// success -> thankyou.php | error -> contact.php?error=...
// ============================================

require_once __DIR__ . '/includes/config.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: contact.php");
    exit;
}

$name    = trim($_POST['name']    ?? '');
$email   = trim($_POST['email']   ?? '');
$subject = trim($_POST['subject'] ?? '');
$message = trim($_POST['message'] ?? '');

// ---- basic validation ----
if ($name === '' || $email === '' || $subject === '' || $message === '') {
    header("Location: contact.php?error=" . urlencode("All fields are required"));
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: contact.php?error=" . urlencode("Please enter a valid email"));
    exit;
}

// ---- (optional) send email — works only on a real PHP server with mail configured ----
$to      = $site_email;
$mailSubject = "Portfolio Contact: " . $subject;
$body    = "Name: $name\nEmail: $email\n\nMessage:\n$message";
$headers = "From: $email" . "\r\n" . "Reply-To: $email";

// Uncomment on a live server with mail() configured:
// @mail($to, $mailSubject, $body, $headers);

// ---- (optional) save to database instead of / in addition to email ----
// $conn = new mysqli("localhost", "db_user", "db_pass", "db_name");
// $stmt = $conn->prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
// $stmt->bind_param("ssss", $name, $email, $subject, $message);
// $stmt->execute();

// store name in session so thankyou.php can greet the user
$_SESSION['contact_name'] = $name;

// ---- PAGE REDIRECT on success ----
header("Location: thankyou.php");
exit;
