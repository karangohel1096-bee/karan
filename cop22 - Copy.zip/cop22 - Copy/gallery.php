<?php
require_once __DIR__ . '/includes/header.php';

// ---- ahiya tamara photos ni list nakho (file name + category) ----
$photos = [
  ["file" => "gallery1.jpg", "cat" => "work",  "title" => "Project One"],
  ["file" => "gallery2.jpg", "cat" => "work",  "title" => "Project Two"],
  ["file" => "gallery3.jpg", "cat" => "personal", "title" => "Me"],
  ["file" => "gallery4.jpg", "cat" => "work",  "title" => "Project Three"],
  ["file" => "gallery5.jpg", "cat" => "personal", "title" => "Behind the scenes"],
  ["file" => "gallery6.jpg", "cat" => "work",  "title" => "Project Four"],
];
?>

<main>
  <section class="page-hero">
    <?php include __DIR__ . '/includes/floating-icons.php'; ?>
    <p class="eyebrow reveal">// 03</p>
    <h1 class="reveal" data-delay="1">My <span class="gold">Gallery</span></h1>
  </section>

  <!-- INTRO STRIP -->
  <section class="intro-strip">
    <div class="marquee">
      <div class="marquee-track">
        <?php
        $marquee_skills = ["HTML5","CSS3","JavaScript","PHP","Laravel","WordPress","Shopify","MySQL","Git","Figma","Bootstrap"];
        for ($r = 0; $r < 2; $r++):
          foreach ($marquee_skills as $s):
        ?>
          <span><?php echo htmlspecialchars($s); ?></span><span class="gold">✦</span>
        <?php
          endforeach;
        endfor;
        ?>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="filter-bar reveal-up">
      <button class="filter-btn active" data-filter="all">All</button>
      <button class="filter-btn" data-filter="work">Work</button>
      <button class="filter-btn" data-filter="personal">Personal</button>
    </div>

    <div class="gallery-grid">
      <?php foreach ($photos as $i => $p): ?>
        <div class="gallery-item reveal-up" data-cat="<?php echo $p['cat']; ?>" data-delay="<?php echo $i % 3; ?>">
          <img src="images/<?php echo $p['file']; ?>"
               alt="<?php echo htmlspecialchars($p['title']); ?>"
               onerror="this.src='https://placehold.co/500x600/141414/c9a961?text=<?php echo urlencode($p['title']); ?>'">
          <div class="gallery-overlay">
            <span><?php echo htmlspecialchars($p['title']); ?></span>
            <em>+</em>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- LIGHTBOX -->
  <div class="lightbox" id="lightbox">
    <button class="lightbox-close" id="lightboxClose">&times;</button>
    <img id="lightboxImg" src="" alt="">
  </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
