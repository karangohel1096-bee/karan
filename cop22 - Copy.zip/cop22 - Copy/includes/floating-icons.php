<div class="floating-icons" aria-hidden="true">
  <span class="ficon f1">&lt;/&gt;</span>
  <span class="ficon f2">{ }</span>
  <span class="ficon f3">PHP</span>
  <span class="ficon f4">JS</span>
  <span class="ficon f5">✦</span>
  <span class="ficon f6">AI</span>
  <span class="ficon f7">#</span>
  <span class="ficon f8">☁</span>
  <span class="ficon f9">( )</span>
  <span class="ficon f10">CSS</span>
  <span class="ficon f11">HTML</span>
  <span class="ficon f12">✧</span>
  <span class="ficon f13">API</span>
  <span class="ficon f14">;</span>
  <span class="ficon f15">DB</span>
  <span class="ficon f16">&lt;&gt;</span>
  <span class="ficon f17">WP</span>
  <span class="ficon f18">npm</span>
  <span class="ficon f19">git</span>
  <span class="ficon f20">SQL</span>
  <span class="ficon f21">REST</span>
  <span class="ficon f22">{ }</span>
  <span class="ficon f23">=&gt;</span>
  <span class="ficon f24">//</span>
  <span class="ficon f25">WC</span>
  <span class="ficon f26">JSON</span>
</div>
