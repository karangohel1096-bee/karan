<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand">
      <span class="gold">&lt;</span><?php echo htmlspecialchars($site_name); ?><span class="gold">/&gt;</span>
      <p><?php echo htmlspecialchars($site_role); ?> — <?php echo htmlspecialchars($site_city); ?></p>
    </div>
    <div class="footer-socials">
      <?php foreach ($socials as $label => $url): ?>
        <a href="<?php echo htmlspecialchars($url); ?>" target="_blank" rel="noopener"><?php echo htmlspecialchars($label); ?></a>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© <?php echo date("Y"); ?> <?php echo htmlspecialchars($site_name); ?>. All rights reserved.</span>
  </div>
</footer>

<a class="whatsapp-float" aria-label="Chat on WhatsApp" title="Chat on WhatsApp"
   href="https://wa.me/<?php echo preg_replace('/\D/', '', $site_phone); ?>?text=<?php echo urlencode('Hi, I saw your portfolio and would like to talk about a project.'); ?>"
   target="_blank" rel="noopener">
  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.5 14.4c-.3-.1-1.7-.9-2-.9-.3-.1-.5-.1-.7.1-.2.3-.8.9-1 1.1-.2.2-.4.2-.6.1-.3-.1-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6.1-.1.3-.4.4-.5.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5C10 9 9.4 7.6 9.2 7c-.2-.5-.4-.5-.6-.5h-.5c-.2 0-.5.1-.7.3-.2.3-.9.9-.9 2.2s1 2.6 1.1 2.7c.1.2 2 3.1 4.9 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.5-.1 1.7-.7 2-1.4.2-.6.2-1.2.2-1.3-.1-.2-.3-.2-.6-.4Z"/><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2Z"/></svg>
</a>

<script src="js/script.js"></script>
</body>
</html>
