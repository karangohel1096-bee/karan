<?php
// ============================================
// SITE CONFIG — tamara badha details ahiya thi j update karo
// (change once here, it reflects on every page)
// ============================================

$site_name   = "Your Name";              // <-- tamaru naam ahiya nakho
$site_role   = "Web Developer & UI Designer";
$site_email  = "you@example.com";
$site_phone  = "+91 90000 00000";
$site_city   = "Rajkot, Gujarat, India";

$roles = [                                // hero ma typing animation ma rotate thase
    "Web Developer",
    "UI / UX Designer",
    "Freelancer",
    "Problem Solver"
];

$socials = [
    "GitHub"    => "https://github.com/yourusername",
    "LinkedIn"  => "https://linkedin.com/in/yourusername",
    "Instagram" => "https://instagram.com/yourusername",
];

// current page (active nav highlight mate)
$current = basename($_SERVER['PHP_SELF']);
