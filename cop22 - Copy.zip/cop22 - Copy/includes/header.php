<?php require_once __DIR__ . '/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($site_name); ?> — <?php echo htmlspecialchars($site_role); ?></title>
<meta name="description" content="Portfolio of <?php echo htmlspecialchars($site_name); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- custom cursor (desktop only, see script.js) -->
<div class="cursor-dot" id="cursorDot"></div>
<div class="cursor-ring" id="cursorRing"></div>

<!-- preloader -->
<div id="preloader">
  <div class="loader-mark">
    <div class="loader-ring"></div>
    <div class="loader-ring slow"></div>
    <span>&lt;<span class="gold">/</span>&gt;</span>
  </div>
</div>

<div class="noise-overlay"></div>

<header class="site-header" id="siteHeader">
  <a href="index.php" class="logo">// <?php echo htmlspecialchars(explode(' ', $site_name)[0]); ?></a>
  <nav class="main-nav" id="mainNav">
    <a href="index.php"   class="<?php echo $current=='index.php'?'active':''; ?>">Home</a>
    <a href="about.php"   class="<?php echo $current=='about.php'?'active':''; ?>">About</a>
    <a href="gallery.php" class="<?php echo $current=='gallery.php'?'active':''; ?>">Gallery</a>
    <a href="contact.php" class="<?php echo $current=='contact.php'?'active':''; ?>">Contact</a>
  </nav>
  <div class="header-socials">
    <?php foreach ($socials as $label => $url): ?>
      <a href="<?php echo htmlspecialchars($url); ?>" target="_blank" rel="noopener" aria-label="<?php echo htmlspecialchars($label); ?>" title="<?php echo htmlspecialchars($label); ?>">
        <?php if ($label === 'GitHub'): ?>
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.57.1.79-.25.79-.55 0-.27-.01-1.17-.02-2.12-3.2.7-3.88-1.36-3.88-1.36-.52-1.33-1.28-1.68-1.28-1.68-1.04-.71.08-.7.08-.7 1.16.08 1.77 1.19 1.77 1.19 1.02 1.76 2.68 1.25 3.34.95.1-.74.4-1.25.72-1.54-2.56-.29-5.25-1.28-5.25-5.7 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.47.11-3.06 0 0 .97-.31 3.18 1.18a11.1 11.1 0 0 1 5.8 0c2.2-1.49 3.18-1.18 3.18-1.18.63 1.6.23 2.77.11 3.06.74.81 1.19 1.83 1.19 3.09 0 4.43-2.7 5.4-5.27 5.69.41.36.78 1.08.78 2.17 0 1.57-.01 2.83-.01 3.22 0 .3.21.66.8.55A10.51 10.51 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5Z"/></svg>
        <?php elseif ($label === 'LinkedIn'): ?>
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5ZM.5 8.98h8.96V23H.5V8.98ZM8.98 8.98h6.44v1.91h.09c.9-1.6 3.1-3.29 6.39-3.29 6.83 0 8.09 4.34 8.09 9.98V23h-8.96v-6.24c0-1.49-.03-3.4-2.07-3.4-2.08 0-2.4 1.62-2.4 3.29V23H8.98V8.98Z" transform="translate(-.5)"/></svg>
        <?php else: ?>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="2.5" y="2.5" width="19" height="19" rx="5"/><circle cx="12" cy="12" r="4.3"/><circle cx="17.2" cy="6.8" r="1"/></svg>
        <?php endif; ?>
      </a>
    <?php endforeach; ?>
  </div>
  <button class="nav-toggle" id="navToggle" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>
</header>
