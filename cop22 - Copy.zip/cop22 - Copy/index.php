<?php require_once __DIR__ . '/includes/header.php'; ?>

<main>
  <!-- HERO -->
  <section class="hero">
    <canvas id="particles"></canvas>
    <?php include __DIR__ . '/includes/floating-icons.php'; ?>
    <div class="hero-inner">
      <p class="eyebrow reveal">// hello, my name is</p>
      <h1 class="hero-name reveal" data-delay="1">Karan Gohel</h1>
      <h2 class="hero-role reveal" data-delay="2">
        I am a <span id="typedRole" class="gold"></span><span class="cursor">|</span>
      </h2>
      <p class="hero-desc reveal" data-delay="3">
        I build clean, fast and thoughtfully designed digital experiences —
        from pixel to production.
      </p>
      <div class="hero-actions reveal" data-delay="4">
        <a href="gallery.php" class="btn btn-gold">View Work</a>
        <a href="contact.php" class="btn btn-outline">Get In Touch</a>
        <a href="files/resume-placeholder.pdf" class="btn btn-cv" download>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v12m0 0-4.5-4.5M12 15l4.5-4.5"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>
          Download CV
        </a>
      </div>
    </div>
    <div class="hero-photo reveal" data-delay="2">
      <div class="photo-ring"></div>
      <img src="images/profile.jpg" alt="<?php echo htmlspecialchars($site_name); ?>" onerror="this.src='https://placehold.co/500x500/1a1a1a/c9a961?text=Your+Photo'">
    </div>
    <a href="#intro" class="scroll-cue"><span></span>Scroll</a>
  </section>

  <!-- INTRO STRIP -->
  <section class="intro-strip" id="intro">
    <div class="marquee">
      <div class="marquee-track" id="marqueeTrack">
        <?php
        $marquee_skills = ["HTML5","CSS3","JavaScript","PHP","Laravel","WordPress","Shopify","MySQL","Git","Figma","Bootstrap"];
        // list ne 2 var repeat karyu che jethi loop seamless (jump vagar) lage
        for ($r = 0; $r < 2; $r++):
          foreach ($marquee_skills as $s):
        ?>
          <span><?php echo htmlspecialchars($s); ?></span><span class="gold">✦</span>
        <?php
          endforeach;
        endfor;
        ?>
      </div>
    </div>
  </section>

  <!-- STATS -->
  <section class="stats-strip">
    <?php
    $stats = [
      ["50+", "Projects Delivered"],
      ["5+",  "Years Experience"],
      ["30+", "Happy Clients"],
      ["100%","Client Satisfaction"],
    ];
    foreach ($stats as $i => $s):
    ?>
      <div class="stat-item reveal-up" data-delay="<?php echo $i; ?>">
        <span class="stat-num gold" data-count="<?php echo htmlspecialchars($s[0]); ?>"><?php echo htmlspecialchars($s[0]); ?></span>
        <span class="stat-label"><?php echo htmlspecialchars($s[1]); ?></span>
      </div>
    <?php endforeach; ?>
  </section>

  <!-- QUICK ABOUT -->
  <section class="section">
    <div class="section-head reveal-up">
      <p class="tag">// 01 — about</p>
      <h2>A little <span class="gold">about me</span></h2>
    </div>
    <div class="about-quick">
      <p class="reveal-up">
        I'm a passionate developer &amp; designer focused on crafting interfaces
        that feel as good as they look. I care about detail, performance and
        clean structured code — this whole site is proof of that.
      </p>
      <a href="about.php" class="link-arrow reveal-up">Read full story →</a>
    </div>
  </section>

  <!-- SERVICES -->
  <section class="section section-alt">
    <div class="section-head reveal-up">
      <p class="tag">// 02 — services</p>
      <h2>What I <span class="gold">do</span></h2>
    </div>
    <div class="services-grid">
      <?php
      $services = [
        ["svg" => '<path d="M8 4 3 12l5 8M16 4l5 8-5 8"/>', "title" => "WordPress Development", "desc" => "Custom themes, ACF flexible content and WooCommerce builds tailored to the client."],
        ["svg" => '<rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 21h8M12 18v3"/>', "title" => "UI / Frontend Design", "desc" => "Pixel-perfect, responsive interfaces built with clean, maintainable HTML/CSS/JS."],
        ["svg" => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>', "title" => "WooCommerce Stores", "desc" => "End-to-end e-commerce builds — carts, checkout, account dashboards and more."],
        ["svg" => '<path d="M12 20V10M18 20V4M6 20v-6"/>', "title" => "Performance & SEO", "desc" => "Fast-loading, well-structured sites optimised for search and real users."],
      ];
      foreach ($services as $i => $sv):
      ?>
        <div class="service-card reveal-up" data-delay="<?php echo $i % 4; ?>">
          <div class="service-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><?php echo $sv['svg']; ?></svg></div>
          <h3><?php echo htmlspecialchars($sv['title']); ?></h3>
          <p><?php echo htmlspecialchars($sv['desc']); ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- FEATURED PROJECTS -->
  <section class="section">
    <div class="section-head reveal-up">
      <p class="tag">// 03 — work</p>
      <h2>Featured <span class="gold">projects</span></h2>
    </div>
    <div class="featured-grid">
      <?php
      $featured = [
        ["file" => "gallery1.jpg", "title" => "Project One", "cat" => "WordPress / WooCommerce"],
        ["file" => "gallery2.jpg", "title" => "Project Two", "cat" => "UI Design"],
        ["file" => "gallery4.jpg", "title" => "Project Three", "cat" => "Frontend Build"],
      ];
      foreach ($featured as $i => $f):
      ?>
        <a href="gallery.php" class="featured-card reveal-up" data-delay="<?php echo $i; ?>">
          <img src="images/<?php echo $f['file']; ?>" alt="<?php echo htmlspecialchars($f['title']); ?>"
               onerror="this.src='https://placehold.co/500x400/141414/c9a961?text=<?php echo urlencode($f['title']); ?>'">
          <div class="featured-overlay">
            <span class="featured-cat"><?php echo htmlspecialchars($f['cat']); ?></span>
            <h3><?php echo htmlspecialchars($f['title']); ?></h3>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
    <div class="featured-cta reveal-up">
      <a href="gallery.php" class="link-arrow">View all work →</a>
    </div>
  </section>

  <!-- SKILLS PREVIEW -->
  <section class="section section-alt">
    <div class="section-head reveal-up">
      <p class="tag">// 04 — stack</p>
      <h2>Tools I <span class="gold">work with</span></h2>
    </div>
    <div class="tools-grid">
      <?php
      $tools = ["HTML5","CSS3","JavaScript","PHP","Laravel","WordPress","Shopify","MySQL","Git","Figma","Bootstrap"];
      foreach ($tools as $i => $t):
      ?>
        <div class="tool-chip reveal-up" data-delay="<?php echo $i % 4; ?>"><?php echo $t; ?></div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- PROCESS -->
  <section class="section process-section">
    <div class="section-head reveal-up">
      <p class="tag">// 05 — how i work</p>
      <h2>From <span class="gold">message</span> to <span class="gold">launch</span></h2>
    </div>
    <div class="process-steps">
      <div class="process-step reveal-up">
        <span class="process-num">01</span>
        <h3>Send a message</h3>
        <p>Share your project details, goals and timeline using the contact form.</p>
      </div>
      <div class="process-step reveal-up" data-delay="1">
        <span class="process-num">02</span>
        <h3>I review &amp; reply</h3>
        <p>I'll get back within 24 hours with initial thoughts or a quote.</p>
      </div>
      <div class="process-step reveal-up" data-delay="2">
        <span class="process-num">03</span>
        <h3>We hop on a call</h3>
        <p>A quick call to align on scope, budget and next steps.</p>
      </div>
      <div class="process-step reveal-up" data-delay="3">
        <span class="process-num">04</span>
        <h3>Build &amp; launch</h3>
        <p>I get to work, keep you updated, and ship a polished result.</p>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="cta-band reveal-up">
    <h2>Got a project in mind?</h2>
    <p>Let's build something worth remembering.</p>
    <a href="contact.php" class="btn btn-gold">Let's Talk</a>
  </section>
</main>

<script>window.PORTFOLIO_ROLES = <?php echo json_encode($roles); ?>;</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
