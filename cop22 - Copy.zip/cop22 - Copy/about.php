<?php require_once __DIR__ . '/includes/header.php'; ?>

<main>
  <section class="page-hero">
    <?php include __DIR__ . '/includes/floating-icons.php'; ?>
    <p class="eyebrow reveal">// 02</p>
    <h1 class="reveal" data-delay="1">About <span class="gold">Me</span></h1>
  </section>

  <!-- INTRO STRIP -->
  <section class="intro-strip">
    <div class="marquee">
      <div class="marquee-track">
        <?php
        $marquee_skills = ["HTML5","CSS3","JavaScript","PHP","Laravel","WordPress","Shopify","MySQL","Git","Figma","Bootstrap"];
        for ($r = 0; $r < 2; $r++):
          foreach ($marquee_skills as $s):
        ?>
          <span><?php echo htmlspecialchars($s); ?></span><span class="gold">✦</span>
        <?php
          endforeach;
        endfor;
        ?>
      </div>
    </div>
  </section>

  <section class="section about-grid">
    <div class="about-photo reveal-up">
      <img src="images/about.jpg" alt="About photo" onerror="this.src='https://placehold.co/450x550/141414/c9a961?text=Photo'">
      <div class="photo-tag">Based in <?php echo htmlspecialchars($site_city); ?></div>
    </div>
    <div class="about-text">
      <p class="tag reveal-up">// who i am</p>
      <h2 class="reveal-up">Hi, I'm <?php echo htmlspecialchars($site_name); ?> —<br>a <span class="gold">builder</span> at heart.</h2>
      <p class="reveal-up">
        I design and build websites that combine strong visuals with clean,
        maintainable code. My process starts with understanding the goal,
        then moves to wireframes, design, and finally pixel-perfect
        development — always keeping performance and usability in mind.
      </p>
      <p class="reveal-up">
        When I'm not coding, I'm usually exploring new design trends,
        experimenting with animation, or improving this very portfolio.
      </p>
      <div class="about-info reveal-up">
        <div><span>Email</span><b><?php echo htmlspecialchars($site_email); ?></b></div>
        <div><span>Phone</span><b><?php echo htmlspecialchars($site_phone); ?></b></div>
        <div><span>Location</span><b><?php echo htmlspecialchars($site_city); ?></b></div>
      </div>
    </div>
  </section>

  <!-- SKILLS -->
  <section class="section section-alt">
    <div class="section-head reveal-up">
      <p class="tag">// 03 — skills</p>
      <h2>What I'm <span class="gold">good at</span></h2>
    </div>
    <div class="skills">
      <?php
      $skills = [
        "HTML / CSS" => 95,
        "JavaScript" => 85,
        "PHP"        => 80,
        "UI Design"  => 90,
        "MySQL"      => 75,
        "Laravel"    => 78,
        "WordPress"  => 85,
        "Shopify"    => 70,
      ];
      foreach ($skills as $name => $pct):
      ?>
      <div class="skill-row reveal-up">
        <div class="skill-label"><span><?php echo $name; ?></span><span class="gold"><?php echo $pct; ?>%</span></div>
        <div class="skill-bar"><div class="skill-fill" data-pct="<?php echo $pct; ?>"></div></div>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- TIMELINE -->
  <section class="section">
    <div class="section-head reveal-up">
      <p class="tag">// 04 — journey</p>
      <h2>My <span class="gold">timeline</span></h2>
    </div>
    <div class="timeline">
      <?php
      $timeline = [
        ["2024 — Present", "Freelance Developer & Designer", "Building websites and brand identities for clients across industries."],
        ["2023", "UI/UX Design Certification", "Deepened focus on user-centered design and prototyping."],
        ["2021 — 2023", "Started Web Development", "Learned HTML, CSS, JavaScript and PHP, building real projects."],
      ];
      foreach ($timeline as $t):
      ?>
      <div class="timeline-item reveal-up">
        <div class="timeline-dot"></div>
        <span class="timeline-date"><?php echo $t[0]; ?></span>
        <h3><?php echo $t[1]; ?></h3>
        <p><?php echo $t[2]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </section>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
