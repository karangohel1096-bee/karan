# My Portfolio — File Guide

## Folder Structure
```
portfolio/
├── index.php              → Home page (hero, typing animation, intro)
├── about.php               → About page (bio, skills bars, timeline)
├── gallery.php              → Photo gallery (filter + lightbox)
├── contact.php               → Contact form
├── contact-process.php        → Handles form POST, validates, PHP redirect()
├── thankyou.php                → Shown after successful form submit
├── includes/
│   ├── config.php               → YOUR NAME, EMAIL, SOCIAL LINKS — edit here first
│   ├── header.php                → Shared nav/head, included on every page
│   └── footer.php                 → Shared footer, included on every page
├── css/
│   └── style.css                   → All styling + animations
├── js/
│   └── script.js                    → Typing effect, particles, scroll reveal,
│                                       gallery filter/lightbox, nav toggle
└── images/                            → PUT YOUR PHOTOS HERE (see below)
```

## 1. Add your details
Open `includes/config.php` and change:
- `$site_name`, `$site_role`, `$site_email`, `$site_phone`, `$site_city`
- `$roles` — the words that type/animate in the hero ("Web Developer", etc.)
- `$socials` — your GitHub / LinkedIn / Instagram links

## 2. Add your photos
Drop these files into the `images/` folder (exact names, or edit the code to match yours):
- `profile.jpg` → hero circular photo
- `about.jpg` → About page photo
- `gallery1.jpg` ... `gallery6.jpg` → Gallery page photos

Until you add real photos, the site shows gold placeholder boxes automatically —
nothing will look broken while you're testing.

To add/remove gallery photos, edit the `$photos` array at the top of `gallery.php`.

## 3. Run it locally
You need PHP installed. Then from inside the `portfolio` folder run:
```
php -S localhost:8000
```
Open `http://localhost:8000` in your browser.

## 4. Deploy
Upload the whole `portfolio` folder to any PHP hosting (Hostinger, InfinityFree,
000webhost, or your own server) — no database is required to run this. The
contact form's `mail()` call is commented out in `contact-process.php`; uncomment
it once your host has mail configured, or wire it to a database instead
(a commented example is included in that file).

## How the "page redirect" works
`contact.php` → form POSTs to `contact-process.php` → PHP validates the data,
then calls `header("Location: ...")` to redirect:
- ✅ success → `thankyou.php`
- ❌ error → back to `contact.php?error=...` (shows a message on the form)
