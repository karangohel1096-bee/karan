<?php
require_once __DIR__ . '/includes/header.php';

// error query param aavse to atlu batavo (redirect back from process file)
$error = isset($_GET['error']) ? $_GET['error'] : '';
?>

<main>
  <section class="page-hero">
    <?php include __DIR__ . '/includes/floating-icons.php'; ?>
    <p class="eyebrow reveal">// 04</p>
    <h1 class="reveal" data-delay="1">Let's <span class="gold">Connect</span></h1>
  </section>

  <!-- INTRO STRIP -->
  <section class="intro-strip">
    <div class="marquee">
      <div class="marquee-track">
        <?php
        $marquee_skills = ["HTML5","CSS3","JavaScript","PHP","Laravel","WordPress","Shopify","MySQL","Git","Figma","Bootstrap"];
        for ($r = 0; $r < 2; $r++):
          foreach ($marquee_skills as $s):
        ?>
          <span><?php echo htmlspecialchars($s); ?></span><span class="gold">✦</span>
        <?php
          endforeach;
        endfor;
        ?>
      </div>
    </div>
  </section>

  <section class="section contact-grid">
    <div class="contact-info reveal-up">
      <p class="tag">// say hello</p>
      <h2>Have a project? Let's talk.</h2>
      <p>Fill the form and I'll get back to you as soon as possible —
         or reach out directly using the details below.</p>

      <div class="contact-details">
        <div class="contact-card reveal-up">
          <div class="contact-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>
          </div>
          <div class="contact-text">
            <span>Email</span>
            <b><?php echo htmlspecialchars($site_email); ?></b>
          </div>
        </div>
        <div class="contact-card reveal-up">
          <div class="contact-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M6.6 10.8c1.4 2.8 3.8 5.2 6.6 6.6l2.2-2.2c.3-.3.7-.4 1.1-.3 1.2.4 2.5.6 3.8.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.6 21 3 13.4 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.6.6 3.8.1.4 0 .8-.3 1.1L6.6 10.8z"/></svg>
          </div>
          <div class="contact-text">
            <span>Phone</span>
            <b><?php echo htmlspecialchars($site_phone); ?></b>
          </div>
        </div>
        <div class="contact-card reveal-up">
          <div class="contact-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 21s-7-6.1-7-11.5A7 7 0 0 1 19 9.5C19 14.9 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.4"/></svg>
          </div>
          <div class="contact-text">
            <span>Location</span>
            <b><?php echo htmlspecialchars($site_city); ?></b>
          </div>
        </div>
      </div>

      <a class="whatsapp-btn reveal-up"
         href="https://wa.me/<?php echo preg_replace('/\D/', '', $site_phone); ?>?text=<?php echo urlencode('Hi, I saw your portfolio and would like to talk about a project.'); ?>"
         target="_blank" rel="noopener">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.5 14.4c-.3-.1-1.7-.9-2-.9-.3-.1-.5-.1-.7.1-.2.3-.8.9-1 1.1-.2.2-.4.2-.6.1-.3-.1-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6.1-.1.3-.4.4-.5.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5C10 9 9.4 7.6 9.2 7c-.2-.5-.4-.5-.6-.5h-.5c-.2 0-.5.1-.7.3-.2.3-.9.9-.9 2.2s1 2.6 1.1 2.7c.1.2 2 3.1 4.9 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.5-.1 1.7-.7 2-1.4.2-.6.2-1.2.2-1.3-.1-.2-.3-.2-.6-.4Z"/><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2Z"/></svg>
        <span>Chat on WhatsApp</span>
      </a>

      <div class="contact-socials">
        <?php foreach ($socials as $label => $url): ?>
          <a href="<?php echo htmlspecialchars($url); ?>" target="_blank" rel="noopener"><?php echo $label; ?></a>
        <?php endforeach; ?>
      </div>
    </div>

    <form class="contact-form reveal-up" action="contact-process.php" method="POST" id="contactForm">
      <?php if ($error): ?>
        <div class="form-alert">⚠ <?php echo htmlspecialchars($error); ?>. Please try again.</div>
      <?php endif; ?>

      <div class="form-row">
        <div class="input-group">
          <input type="text" name="name" id="name" required placeholder=" ">
          <label for="name">Your Name</label>
        </div>
        <div class="input-group">
          <input type="email" name="email" id="email" required placeholder=" ">
          <label for="email">Your Email</label>
        </div>
      </div>
      <div class="input-group">
        <input type="text" name="subject" id="subject" required placeholder=" ">
        <label for="subject">Subject</label>
      </div>
      <div class="input-group">
        <textarea name="message" id="message" rows="5" required placeholder=" "></textarea>
        <label for="message">Your Message</label>
      </div>
      <button type="submit" class="btn btn-gold btn-full">Send Message</button>

      <div class="availability-note">
        <span class="status-dot"></span>
        <div>
          <b>Currently available for new projects</b>
          <p>Usually replies within 24 hours.</p>
        </div>
      </div>

      <div class="form-highlights">
        <div class="highlight-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 6 9 17l-5-5"/></svg>
          <span>Free initial consultation</span>
        </div>
        <div class="highlight-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 6 9 17l-5-5"/></svg>
          <span>Flexible working hours</span>
        </div>
        <div class="highlight-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 6 9 17l-5-5"/></svg>
          <span>Clear, regular communication</span>
        </div>
      </div>
    </form>
  </section>

  <!-- PROCESS -->
  <section class="section section-alt process-section">
    <div class="section-head reveal-up">
      <p class="tag">// how it works</p>
      <h2>From <span class="gold">message</span> to <span class="gold">launch</span></h2>
    </div>
    <div class="process-steps">
      <div class="process-step reveal-up">
        <span class="process-num">01</span>
        <h3>Send a message</h3>
        <p>Share your project details, goals and timeline using the form or WhatsApp.</p>
      </div>
      <div class="process-step reveal-up" data-delay="1">
        <span class="process-num">02</span>
        <h3>I review &amp; reply</h3>
        <p>I'll get back within 24 hours with initial thoughts, questions or a quote.</p>
      </div>
      <div class="process-step reveal-up" data-delay="2">
        <span class="process-num">03</span>
        <h3>We hop on a call</h3>
        <p>A quick call to align on scope, budget and next steps.</p>
      </div>
      <div class="process-step reveal-up" data-delay="3">
        <span class="process-num">04</span>
        <h3>Build &amp; launch</h3>
        <p>I get to work, keep you updated, and ship a polished result.</p>
      </div>
    </div>
  </section>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
