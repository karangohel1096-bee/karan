// ============================================================
// PORTFOLIO — main script (static single-page version, no PHP)
// ============================================================
document.addEventListener('DOMContentLoaded', () => {

  /* ---------- footer year ---------- */
  const footerYear = document.getElementById('footerYear');
  if (footerYear) footerYear.textContent = new Date().getFullYear();

  /* ---------- preloader ---------- */
  const preloader = document.getElementById('preloader');
  const showPreloader = () => preloader && preloader.classList.remove('hide');
  const hidePreloader = () => preloader && preloader.classList.add('hide');

  window.addEventListener('load', () => {
    setTimeout(hidePreloader, 400);
  });
  // fallback in case load already fired
  setTimeout(hidePreloader, 1800);

  /* ---------- sticky header shrink ---------- */
  const header = document.getElementById('siteHeader');
  if (header) {
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 40);
    });
  }

  /* ---------- mobile nav toggle ---------- */
  const navToggle = document.getElementById('navToggle');
  const mainNav = document.getElementById('mainNav');
  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      mainNav.classList.toggle('open');
      navToggle.classList.toggle('open');
    });
    mainNav.querySelectorAll('a').forEach(a =>
      a.addEventListener('click', () => mainNav.classList.remove('open'))
    );
  }

  /* ============================================================
     SPA PAGE ROUTER
     Every "page" (home / about / gallery / contact / thankyou) lives
     in the same HTML file as a <div class="page" id="page-XXX">.
     Clicking any [data-page] link swaps the visible page instead of
     doing a real navigation — this is what replaces the old PHP
     multi-file setup (index.php / about.php / gallery.php / ...).
     ============================================================ */
  const pages = document.querySelectorAll('.page');
  const navLinks = document.querySelectorAll('[data-page]');
  const siteTitleBase = 'Karan Gohel — Web Developer & UI Designer';

  function showPage(name, opts) {
    opts = opts || {};
    let found = false;
    pages.forEach(p => {
      const isMatch = p.id === 'page-' + name;
      p.classList.toggle('active-page', isMatch);
      if (isMatch) {
        found = true;
        const t = p.getAttribute('data-title');
        document.title = t || siteTitleBase;
      }
    });
    if (!found) return; // unknown page/hash — do nothing

    // update nav active state (thankyou / unlisted pages just clear all)
    navLinks.forEach(a => {
      if (a.closest('.main-nav') || a.classList.contains('logo')) {
        a.classList.toggle('active', a.dataset.page === name);
      }
    });

    if (!opts.skipScroll) window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });

    // re-run reveal animations for the page we just switched to,
    // mirroring how a fresh PHP page load would animate in
    const target = document.getElementById('page-' + name);
    if (target) {
      const revealEls = target.querySelectorAll('.reveal, .reveal-up');
      revealEls.forEach(el => {
        el.classList.remove('in');
        // force reflow so the transition replays
        void el.offsetWidth;
        requestAnimationFrame(() => {
          requestAnimationFrame(() => el.classList.add('in'));
        });
      });
      // re-arm skill bars + stat counters for this page view
      target.querySelectorAll('.skill-fill').forEach(el => { el.style.width = '0'; });
      target.querySelectorAll('.stat-num[data-count]').forEach(el => {
        el.textContent = el.dataset.count;
      });
      armObservers(target);
    }
  }

  function currentHashPage() {
    const h = (location.hash || '#home').replace('#', '');
    return ['home', 'about', 'gallery', 'contact', 'thankyou'].includes(h) ? h : 'home';
  }

  navLinks.forEach(a => {
    a.addEventListener('click', (e) => {
      const page = a.dataset.page;
      if (!page) return;
      // show the loader for every in-app "page" switch too, not just
      // the very first real load/refresh, so nav clicks feel consistent
      if (page !== currentHashPage()) {
        showPreloader();
        setTimeout(hidePreloader, 500);
      }
      // let the browser update the hash naturally, then route
      setTimeout(() => showPage(page), 0);
    });
  });

  window.addEventListener('hashchange', () => showPage(currentHashPage()));

  /* ---------- scroll reveal (IntersectionObserver) ---------- */
  let io = null;
  function armObservers(scope) {
    scope = scope || document;
    if (!io) {
      io = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in');
            io.unobserve(entry.target);
          }
        });
      }, { threshold: 0.15 });
    }
    scope.querySelectorAll('.reveal, .reveal-up').forEach(el => io.observe(el));

    if (!skillIO) {
      skillIO = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.style.width = entry.target.dataset.pct + '%';
            skillIO.unobserve(entry.target);
          }
        });
      }, { threshold: 0.4 });
    }
    scope.querySelectorAll('.skill-fill').forEach(el => skillIO.observe(el));

    if (!statIO) {
      statIO = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (!entry.isIntersecting) return;
          const el = entry.target;
          const raw = el.dataset.count;
          const target2 = parseInt(raw.replace(/\D/g, ''), 10) || 0;
          const suffix = raw.replace(/[0-9]/g, '');
          const duration = 1200;
          const start = performance.now();
          function tick(now) {
            const progress = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = Math.round(target2 * eased) + suffix;
            if (progress < 1) requestAnimationFrame(tick);
          }
          requestAnimationFrame(tick);
          statIO.unobserve(el);
        });
      }, { threshold: 0.4 });
    }
    scope.querySelectorAll('.stat-num[data-count]').forEach(el => statIO.observe(el));
  }
  let skillIO = null;
  let statIO = null;

  armObservers(document);

  // hero elements reveal immediately on load (not on scroll)
  document.querySelectorAll('.hero .reveal').forEach(el => {
    setTimeout(() => el.classList.add('in'), 100);
  });

  /* ---------- typing role animation ---------- */
  const typedEl = document.getElementById('typedRole');
  if (typedEl && window.PORTFOLIO_ROLES && window.PORTFOLIO_ROLES.length) {
    const roles = window.PORTFOLIO_ROLES;
    let roleIndex = 0, charIndex = 0, deleting = false;

    function typeLoop() {
      const current = roles[roleIndex];
      if (!deleting) {
        charIndex++;
        typedEl.textContent = current.slice(0, charIndex);
        if (charIndex === current.length) {
          deleting = true;
          setTimeout(typeLoop, 1400);
          return;
        }
      } else {
        charIndex--;
        typedEl.textContent = current.slice(0, charIndex);
        if (charIndex === 0) {
          deleting = false;
          roleIndex = (roleIndex + 1) % roles.length;
        }
      }
      setTimeout(typeLoop, deleting ? 40 : 80);
    }
    typeLoop();
  }

  /* ---------- gallery filter ---------- */
  const filterBtns = document.querySelectorAll('.filter-btn');
  const galleryItems = document.querySelectorAll('.gallery-item');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.dataset.filter;
      galleryItems.forEach(item => {
        const show = filter === 'all' || item.dataset.cat === filter;
        item.classList.toggle('hidden-item', !show);
      });
    });
  });

  /* ---------- lightbox ---------- */
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  const lightboxClose = document.getElementById('lightboxClose');
  galleryItems.forEach(item => {
    item.addEventListener('click', () => {
      const img = item.querySelector('img');
      if (!lightbox || !img) return;
      lightboxImg.src = img.src;
      lightboxImg.alt = img.alt;
      lightbox.classList.add('open');
    });
  });
  if (lightboxClose) lightboxClose.addEventListener('click', () => lightbox.classList.remove('open'));
  if (lightbox) lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) lightbox.classList.remove('open');
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && lightbox) lightbox.classList.remove('open');
  });

  /* ---------- custom cursor ---------- */
  const cursorDot = document.getElementById('cursorDot');
  const cursorRing = document.getElementById('cursorRing');
  const isFinePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  if (cursorDot && cursorRing && isFinePointer) {
    let mouseX = 0, mouseY = 0, ringX = 0, ringY = 0;
    let shown = false;

    window.addEventListener('mousemove', (e) => {
      mouseX = e.clientX; mouseY = e.clientY;
      cursorDot.style.left = mouseX + 'px';
      cursorDot.style.top = mouseY + 'px';
      if (!shown) {
        cursorDot.classList.add('show');
        cursorRing.classList.add('show');
        shown = true;
      }
    });

    // ring follows with slight lag for a smooth trailing feel
    function animateRing() {
      ringX += (mouseX - ringX) * 0.16;
      ringY += (mouseY - ringY) * 0.16;
      cursorRing.style.left = ringX + 'px';
      cursorRing.style.top = ringY + 'px';
      requestAnimationFrame(animateRing);
    }
    animateRing();

    // scale up on interactive elements
    const hoverTargets = 'a, button, .gallery-item, .filter-btn, input, textarea, .tool-chip';
    document.addEventListener('mouseover', (e) => {
      if (e.target.closest(hoverTargets)) cursorRing.classList.add('hover');
    });
    document.addEventListener('mouseout', (e) => {
      if (e.target.closest(hoverTargets)) cursorRing.classList.remove('hover');
    });

    document.addEventListener('mouseleave', () => {
      cursorDot.classList.remove('show');
      cursorRing.classList.remove('show');
      shown = false;
    });
  }

  /* ---------- click burst: code icons radiate outward from click point ---------- */
  const codeSymbols = ['</>', '{ }', ';', '#', '=>', '( )', '<>', '//', 'PHP', 'JS', 'WP', 'CSS'];
  document.addEventListener('click', (e) => {
    const count = 6 + Math.floor(Math.random() * 2); // 6-7 particles
    const baseAngle = Math.random() * 360;

    for (let i = 0; i < count; i++) {
      const el = document.createElement('span');
      el.className = 'click-code';

      // spread particles evenly around a circle, with slight randomness
      const angle = (baseAngle + (360 / count) * i + (Math.random() * 20 - 10)) * (Math.PI / 180);
      const distance = 55 + Math.random() * 55; // px travel distance
      const tx = Math.cos(angle) * distance;
      const ty = Math.sin(angle) * distance;
      const rot = (Math.random() * 60 - 30);

      el.style.setProperty('--tx', tx.toFixed(1) + 'px');
      el.style.setProperty('--ty', ty.toFixed(1) + 'px');
      el.style.setProperty('--rot', rot.toFixed(1) + 'deg');
      el.style.left = e.clientX + 'px';
      el.style.top = e.clientY + 'px';
      el.style.fontSize = (0.75 + Math.random() * 0.55) + 'rem';
      el.style.animationDelay = (i * 18) + 'ms';
      el.textContent = codeSymbols[Math.floor(Math.random() * codeSymbols.length)];

      document.body.appendChild(el);
      el.addEventListener('animationend', () => el.remove());
      setTimeout(() => el.remove(), 1400);
    }
  });

  /* ---------- particle background (hero) ---------- */
  const canvas = document.getElementById('particles');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let particles = [];
    function resize() {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    }
    function initParticles() {
      const count = Math.min(60, Math.floor(canvas.width / 20));
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.6 + 0.4,
        vx: (Math.random() - 0.5) * 0.25,
        vy: (Math.random() - 0.5) * 0.25,
        o: Math.random() * 0.5 + 0.1
      }));
    }
    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(201,169,97,${p.o})`;
        ctx.fill();
      });
      requestAnimationFrame(animate);
    }
    resize();
    initParticles();
    animate();
    window.addEventListener('resize', () => { resize(); initParticles(); });
  }

  /* ============================================================
     CONTACT FORM
     Static replacement for contact.php -> contact-process.php ->
     thankyou.php. All validation now happens client-side in JS;
     on success we swap straight to the "thank you" page and greet
     the visitor by name (same as the old PHP session did).
     ============================================================ */
  const contactForm = document.getElementById('contactForm');
  const formAlert = document.getElementById('formAlert');
  const formAlertMsg = document.getElementById('formAlertMsg');
  const thankyouName = document.getElementById('thankyouName');

  function showFormError(msg) {
    if (!formAlert) return;
    formAlertMsg.textContent = msg;
    formAlert.style.display = 'block';
  }
  function hideFormError() {
    if (!formAlert) return;
    formAlert.style.display = 'none';
  }

  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const btn = contactForm.querySelector('button[type="submit"]');

      const name = contactForm.name.value.trim();
      const email = contactForm.email.value.trim();
      const subject = contactForm.subject.value.trim();
      const message = contactForm.message.value.trim();

      if (!name || !email || !subject || !message) {
        showFormError('All fields are required');
        return;
      }
      if (!isValidEmail(email)) {
        showFormError('Please enter a valid email');
        return;
      }

      hideFormError();
      if (btn) { btn.textContent = 'Sending...'; btn.disabled = true; }

      // simulate the old server round-trip, then redirect to thankyou
      setTimeout(() => {
        if (thankyouName) thankyouName.textContent = name;
        location.hash = '#thankyou';
        showPage('thankyou');
        contactForm.reset();
        if (btn) { btn.textContent = 'Send Message'; btn.disabled = false; }
      }, 500);
    });
  }

  /* ---------- initial route on page load ---------- */
  showPage(currentHashPage(), { skipScroll: true });

  /* ---------- whatsapp popup chatbox ---------- */
  const waFloat = document.getElementById('whatsappFloat');
  const waBox = document.getElementById('whatsappChatbox');
  const waClose = document.getElementById('whatsappClose');
  const waForm = document.getElementById('whatsappForm');
  const waInput = document.getElementById('whatsappMessage');
  const waPhone = '917863899564';

  if (waBox && waFloat) {
    const openChatbox = () => waBox.classList.add('open');
    const closeChatbox = () => waBox.classList.remove('open');

    // auto-open the popup 2 seconds after every page load/refresh
    setTimeout(openChatbox, 2000);

    // clicking the floating button toggles the popup instead of
    // navigating straight away, so people can type a custom message
    waFloat.addEventListener('click', (e) => {
      e.preventDefault();
      waBox.classList.toggle('open');
    });

    if (waClose) {
      waClose.addEventListener('click', closeChatbox);
    }

    if (waForm) {
      waForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = (waInput && waInput.value.trim()) ||
          'Hi, I saw your portfolio and would like to talk about a project.';
        window.open(`https://wa.me/${waPhone}?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
        if (waInput) waInput.value = '';
        closeChatbox();
      });
    }
  }
});
